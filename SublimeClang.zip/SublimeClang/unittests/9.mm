#import <Cocoa/Cocoa.h>

typedef struct
{
    id context;
} Test;

